$(document).ready(function(){
    let blogId = 0;

    $(document).on("click", "#div_blog_table table button.btn_comment", function() {
        let btn_id = (event.srcElement.id);
        blogId = btn_id.split("_")[2];
    });

    $(document).on("click", "#model-add-comment", function() {
    	
    	let formdata = {
            	body : $("#body").val(),
            	 }
        $.ajax({
            url: '/api/blog/' + blogId+'/comment',
            type: 'POST',
            contentType:'application/json',
        	data:JSON.stringify(formdata),
        	dataType:'json',
        	async:false,
        	cache:false,
            success: function(response) {
                $("div.modal-body-comment")
                    .text("Comment Added Successfully!");

                $("#model-add-comment").css({"display": "none"});
                $("button.btn.btn-secondary-comment").text("Close");
            },
            error: function(error){
                console.log(error);
                $("#div_blog_updating").css({"display": "none"});
                alert("Error -> " + error);
            }
        });
    });
});