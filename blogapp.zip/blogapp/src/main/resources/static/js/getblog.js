$(document).ready(function(){
    (function(){
        $.ajax({
            type : "GET",
            url : "/api/blog/getAllBlogs",
            success: function(response){
              $.each(response.blogs, (i, blog) => {  

              /*  <button type="button" class="btn btn-danger btn_delete" data-toggle="modal" data-target="#myModal">
                Open modal
              </button>*/

                let deleteButton = '<button ' +
                                        'id=' +
                                        '\"' + 'btn_delete_' + blog.id + '\"'+
                                        ' type="button" class="btn btn-danger btn_delete" data-toggle="modal" data-target="#delete-modal"' +
                                        '>&times</button>';

                let get_More_Info_Btn = '<button' +
                                            ' id=' + '\"' + 'btn_id_' + blog.id + '\"' +
                                            ' type="button" class="btn btn-info btn_id">' + 
                                            blog.id +
                                            '</button>';
                
                let add_comment = '<button' +
                ' id=' + '\"' + 'btn_comment_' + blog.id + '\"' +
                ' type="button" class="btn btn-primary btn_comment" data-toggle="modal"  data-target="#add-comment-modal">' + 
                 'Comment'

                '</button>';
                
                
                
                let tr_id = 'tr_' + blog.id;
                let blogRow = '<tr id=\"' + tr_id + "\"" + '>' +
                          '<td>' + get_More_Info_Btn + '</td>' +
                          '<td class=\"td_title\">' + blog.title + '</td>' +
                          '<td class=\"td_body\">' + blog.body+ '</td>' +
                          '<td class=\"td_author\">' + blog.author+ '</td>' +

                          '<td>' + deleteButton + '</td>' +
                          '<td>' + add_comment + '</td>' +

                          '</tr>';                
                $('#blogTable tbody').append(blogRow);
              });
            },
            error : function(e) {
              alert("ERROR: ", e);
              console.log("ERROR: ", e);
            }
        });
    })();        
    
    (function(){
        let pathname = window.location.pathname;
        if (pathname == "/blogs.html") {
            $(".nav .nav-item a:last").addClass("active");
        }
    })();
});