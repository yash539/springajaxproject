$(document).ready(function(){
	$("#add_new_blog").submit(function(evt){
        evt.preventDefault();
        let formdata = {
        	title : $("#title").val(),
        	body : $("#body").val(),
        	author : $("#author").val()
        	 }
        
        $.ajax({
        	url: '/api/blog/createBlog', 
        	type:'POST' ,
        	contentType:'application/json',
        	data:JSON.stringify(formdata),
        	dataType:'json',
        	async:false,
        	cache:false,
        	success: function (response) {
                let blog = response.blogs[0];
                let blogString = "{ title: " + blog.title + 
                                            ", body: " + blog.body + 
                                            ", author: " + blog.author
                                             " }"
                let successAlert = '<div class="alert alert-success alert-dismissible">' + 
                                        '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                                        '<strong>' + response.message + '</strong> Blog\'s Info = ' + blogString;
                                    '</div>'
                $("#response").append(successAlert);
                $("#response").css({"display": "block"});

                resetUploadForm();
            },
            error: function (response) {
                let errorAlert = '<div class="alert alert-danger alert-dismissible">' + 
                                    '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                                    '<strong>' + response.message + '</strong>' + ' ,Error: ' + message.error + 
                                '</div>'
                $("#response").append(errorAlert);
                $("#response").css({"display": "block"});

                resetUploadForm();
            }
        });
	});
	
	 function resetUploadForm(){
	        $("#title").val("");
	        $("#body").val("");
	        $("#author").val("");
	        
	    }

	    (function(){
	        let pathname = window.location.pathname;
	        if(pathname === "/"){
	            $(".nav .nav-item a:first").addClass("active");
	        } else if (pathname == "/customers.html") {
	            $(".nav .nav-item a:last").addClass("active");
	        }
	    })();
});