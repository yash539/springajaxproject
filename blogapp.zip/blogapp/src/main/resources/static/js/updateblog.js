$(document).ready(function(){
    $("#update_blog_form").submit(function(evt) {
        evt.preventDefault();
        try {
            let blogId = $("#blog_id").val();

            // PREPARE FORM DATA
            let formData = {
                title : $("#blog_title").val(),
                body :  $("#blog_body").val(),
                author: $("#blog_author").val(),
            }
            
            $.ajax({
                url: '/api/blog/updatebyid/' + blogId + "/",
                type: 'PUT',
                contentType : "application/json",
                data: JSON.stringify(formData),
                dataType : 'json',
                async: false,
                cache: false,
                success: function (response) {
                    let blog = response.blogs[0];
                    let blogString = "{ title: " + blog.title + 
                    ", body: " + blog.body + 
                    ", author: " + blog.author
                     " }"
                    let successAlert = '<div class="alert alert-success alert-dismissible">' + 
                                            '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                                            '<strong>' + response.message + '</strong> Blog\'s Info = ' + blogString;
                                        '</div>'

                 
                    $("#response").empty();
                    $("#response").append(successAlert);
                    $("#response").css({"display": "block"});
                },
                
                // change the updated data for customer table record


                error: function (response) {
                    let errorAlert = '<div class="alert alert-danger alert-dismissible">' + 
                                        '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                                        '<strong>' + response.message + '</strong>' + ' ,Error: ' + message.error + 
                                    '</div>';

                    $("#response").empty();                                    
                    $("#response").append(errorAlert);
                    $("#response").css({"display": "block"});
                }
            });
        } catch(error){
            console.log(error);
            alert(error);
        }
    });

    $(document).on("click", "table button.btn_id", function(){
        let id_of_button = (event.srcElement.id);
        let blogId = id_of_button.split("_")[2];
  
        $.ajax({
            url: '/api/blog/getBlogById/' + blogId,
            type: 'GET',
            success: function(response) {
                let blog = response.blogs[0];                
                $("#blog_id").val(blog.id);
                $("#blog_title").val(blog.title);
                $("#blog_body").val(blog.body);
                $("#blog_author").val(blog.author);
                $("#div_blog_updating").css({"display": "block"});
            },
            error: function(error){
                console.log(error);
                alert("Error -> " + error);
            }
        });        
    });
});