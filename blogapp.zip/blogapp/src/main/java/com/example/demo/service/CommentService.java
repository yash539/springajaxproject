package com.example.demo.service;

import com.example.demo.model.Comments;

public interface CommentService {

	public Comments addComment(Comments comment,Long id);
}
