package com.example.demo.model;

import java.util.Date;
import java.util.List;

public class BlogDTO {
	
	private long id;
	private String title;
    private String body;
	private Date createdDate;
    private List<commentsDTO> comments;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public List<commentsDTO> getComments() {
		return comments;
	}
	public void setComments(List<commentsDTO> comments) {
		this.comments = comments;
	}

}
