package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

public class Response {
	private String message = "";
	private List<Blog> blogs = new ArrayList<Blog>();
	private String error = "";
	private List<Comments> comments = new ArrayList<Comments>();
	private List<BlogDTO> blogDTO = new ArrayList<BlogDTO>();
	public Response(String message, List<Blog> blogs, String error) {
		super();
		this.message = message;
		this.blogs = blogs;
		this.error = error;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

	
	public Response(String message, List<BlogDTO> blogDTO) {
		super();
		this.message = message;
		this.blogDTO = blogDTO;
	}
	public Response(String message, String error, List<Comments> comments) {
		super();
		this.message = message;
		this.error = error;
		this.comments = comments;
	}
	public List<Blog> getBlogs() {
		return blogs;
	}
	public void setBlogs(List<Blog> blogs) {
		this.blogs = blogs;
	}
	public String getError() {
		return error;
	}
	public List<Comments> getComments() {
		return comments;
	}
	public void setComments(List<Comments> comments) {
		this.comments = comments;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
