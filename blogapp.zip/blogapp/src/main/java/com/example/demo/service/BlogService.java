package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Blog;
import com.example.demo.model.BlogDTO;

public interface BlogService {
	public Blog saveBlog(Blog blog);

	List<Blog> getAllBlogs();

	public Blog getBlogById(Long Id);

	public boolean checkExistingBlog(Long id);

	public Blog updateBlog(Blog blog);

	public void deleteBlogById(Long id);

	BlogDTO getBlogWithCommentsById(Long Id);
}
