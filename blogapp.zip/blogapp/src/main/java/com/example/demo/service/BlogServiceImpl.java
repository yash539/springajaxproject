package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.example.demo.model.Blog;
import com.example.demo.model.BlogDTO;
import com.example.demo.model.Comments;
import com.example.demo.repository.BlogRepository;
import com.example.demo.repository.CommentsRepository;

@Service
public class BlogServiceImpl implements BlogService {

	@Autowired
	BlogRepository blogRepository;
	
	@Autowired
	CommentsRepository commentRepository;

	@Override
	public Blog saveBlog(Blog blog) {
		return this.blogRepository.save(blog);
	}

	@Override
	public List<Blog> getAllBlogs() {
		// TODO Auto-generated method stub
		return this.blogRepository.findAll();
	}

	@Override
	public Blog getBlogById(Long Id) {
		// TODO Auto-generated method stub
	   Blog getBlog = this.blogRepository.findById(Id).get();
	   return getBlog;
	}

	@Override
	public boolean checkExistingBlog(Long id) {
		// TODO Auto-generated method stub
		if (blogRepository.existsById(id)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Blog updateBlog(Blog blog) {
		// TODO Auto-generated method stub
		return this.blogRepository.save(blog);
	}

	@Override
	public void deleteBlogById(Long id) {
		// TODO Auto-generated method stub
		
		List<Comments> blogComments = this.commentRepository.findByBlogId(id);
		if(!CollectionUtils.isEmpty(blogComments)) {
			this.commentRepository.deleteAll(blogComments);
		}
		this.blogRepository.deleteById(id);

	}

	@Override
	public BlogDTO getBlogWithCommentsById(Long Id) {
		// TODO Auto-generated method stub
		return null;
	}

}
