package com.example.demo.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Blog;
import com.example.demo.model.Comments;
import com.example.demo.model.Response;
import com.example.demo.service.CommentService;

@RestController
@RequestMapping("/api/blog")
public class CommentController {
	
	@Autowired
	public CommentService commentsService;
	
	@PostMapping("/{id}/comment")
	public ResponseEntity<Response> createNewBlog(@RequestBody Comments comments ,@PathVariable Long id) {
		try {
			Comments commentToSave  = this.commentsService.addComment(comments,id);
			return new ResponseEntity<Response>(
					new Response("New Comment Successfully", "",Arrays.asList(commentToSave)), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response("Fail to post Comment on Blog!", e.getMessage(),null ),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}
