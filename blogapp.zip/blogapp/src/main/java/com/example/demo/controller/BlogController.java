package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Blog;
import com.example.demo.model.Response;
import com.example.demo.service.BlogService;

@RestController
@RequestMapping("/api/blog")
public class BlogController {
	@Autowired
	BlogService blogService;

	@PostMapping("/createBlog")
	public ResponseEntity<Response> createNewBlog(@RequestBody Blog blog) {
		try {
			Blog blogToSave = this.blogService.saveBlog(blog);
			return new ResponseEntity<Response>(
					new Response("New Blog Uploaded Successfully", Arrays.asList(blogToSave), ""), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response("Fail to post Blog!", null, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("/getAllBlogs")
	public ResponseEntity<Response> getAllBlogs() {
		try {
			List<Blog> retriveBlogs = this.blogService.getAllBlogs();
			return new ResponseEntity<Response>(new Response("Blogs Data", retriveBlogs, ""), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response("Fail to Fetch Blogs!", null, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getBlogById/{id}")
	public ResponseEntity<Response> getBlogById(@PathVariable long id) {
		try {
			Blog retriveBlogs = this.blogService.getBlogById(id);
			return new ResponseEntity<Response>(
					new Response("Successfully Fetched Blog with", Arrays.asList(retriveBlogs), ""),
					HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Response>(
					new Response("Fail to Fetch Blog!", null, "Blog Not Found With id = " + id),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/updatebyid/{id}")
	public ResponseEntity<Response> updateBlogById(@RequestBody Blog updatedBlog, @PathVariable long id) {
		try {
			if (blogService.checkExistingBlog(id)) {
				Blog existingBlog = blogService.getBlogById(id);

				// set new values for blog
				existingBlog.setBody(updatedBlog.getBody());
				existingBlog.setCreatedDate(updatedBlog.getCreatedDate());
				existingBlog.setTitle(updatedBlog.getTitle());
				existingBlog.setId(existingBlog.getId());
				existingBlog.setAuthor(existingBlog.getAuthor());

				// save the change to database
				Blog newBlog = blogService.updateBlog(existingBlog);
				return new ResponseEntity<Response>(
						new Response("Successfully! Updated a Blog " + "with id = " + id, Arrays.asList(newBlog), ""),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<Response>(
						new Response("Blog Not Found " + "with id = " + id, null, ""),
						HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response("Failure", null, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/deletebyid/{id}")
	public ResponseEntity<Response> deleteBlogById(@PathVariable long id) {
		try {
			if (blogService.checkExistingBlog(id)) {
				blogService.deleteBlogById(id);

				return new ResponseEntity<Response>(
						new Response("Successfully! Delete a Blog with id = " + id, null, ""), HttpStatus.OK);
			} else {
				return new ResponseEntity<Response>(
						new Response("Blog Not Found " + "with id = " + id, null, ""),
						HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<Response>(new Response("Failure", null, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
