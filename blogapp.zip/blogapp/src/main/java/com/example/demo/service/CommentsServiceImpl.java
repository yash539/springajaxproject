package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Blog;
import com.example.demo.model.Comments;
import com.example.demo.repository.CommentsRepository;
@Service
public class CommentsServiceImpl implements CommentService {

	@Autowired
	public CommentsRepository commentsRepository;
	@Autowired
	public BlogService blogService;
	@Override
	public Comments addComment(Comments comment,Long id) {
		Blog getBlog = this.blogService.getBlogById(id);
		
		comment.setBlog(getBlog);
		return this.commentsRepository.save(comment);
	}

}
